$('.owl-carousel').owlCarousel({
    loop:true,
    margin:15,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:3,
            nav:false
        },
        1400:{
            items:5,
            nav:true,
            loop:false
        }
    }
})

//Модальное окно HOME
var licBtn = document.getElementById('lic-btn');
var homeClose = document.getElementById('home-close');
var homeModal = document.getElementById('home-modal');

var homeMenu = document.getElementById("check-menu");

licBtn.onclick = function(e){
    e.preventDefault();
    homeModal.classList.remove("visually-hidden");
    homeMenu.checked = false;
};

homeClose.onclick = function(){
    homeModal.classList.add("visually-hidden");
}

//Модальное окно ABOUT
var aboutBtn = document.getElementById('about-btn');
var aboutClose = document.getElementById('about-close');
var aboutModal = document.getElementById('about-modal');

aboutBtn.onclick = function(e){
    e.preventDefault();
    aboutModal.classList.remove("visually-hidden");
};

aboutClose.onclick = function(){
    aboutModal.classList.add("visually-hidden");
}

//Модальное окно ROUTINE
var routineBtn = document.getElementById('routine-btn');
var modalClose = document.getElementById('modal-close');
var routineModal = document.getElementById('routine-modal');

routineBtn.onclick = function(e){
    e.preventDefault();
    routineModal.classList.remove("visually-hidden");
};

modalClose.onclick = function(){
    routineModal.classList.add("visually-hidden");
}

